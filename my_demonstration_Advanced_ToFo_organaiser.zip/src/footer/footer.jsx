import React from "react";
import "./footer.css";

function Foooter() {
    return (
        <footer>            
            <div className="footerTop">
                Это футер
            </div>
            
            <div className="footerBottom">
                <div className="subFootLeft"></div>
                <div className="subFooCenter"></div>
                <div className="subFootRight"></div>
            </div>
        </footer>
    )
}

export default Foooter;





