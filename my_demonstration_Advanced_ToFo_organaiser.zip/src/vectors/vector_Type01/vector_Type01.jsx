import React from "react";
import "./vector_Type01.css";

export {Vector_Type01_Bottom, Vector_Type01_Right};

function Vector_Type01_Bottom() {
    return (
        <div className="vectorContenner">
        </div>
    )
}

function Vector_Type01_Right() {
    return (
        <div className="vectorContenner right">
        </div>
    )
}
